// Get those variables declared
// create event listener for when the div is clicked
// flip over the card when it's clicked
// itialize state function
// compare choices after the click
// divs id's match, disable click functionality 
// if there is no match, return back to image
// create reset button
// calc clicks function


//Cache'd Dom Elements
const cards = document.querySelectorAll('.matching-card')

cards.forEach(card => card.addEventListener('click', takeTurn))

var cardOneId = document.getElementById("clapping")
var cardTwoId = document.getElementById("clappingTwo")


//Variables
let cardArray = ["clapping", "tears", "magic", "five", "cry", 
"young", "clapping", "tears", "magic", "five", "cry", "young"]

let cardOne; 
let cardTwo;
let previousClick = ""
let justClicked = ""

// cardOne = 



//fuctions 

function takeTurn(evt){ 
    //adding a class (flipped) to whatever is clicked-> class makes card do 180deg flip
    this.classList.toggle('flipped')
    console.log("this class was flipped")
// if there is nothing in the justClicked variable... justclicked get's the even with the dataset name
//card one is saving the event target
    if (justClicked === ""){
    justClicked = evt.target.dataset.name
        cardOne = this;
        }
// if there is something in justClicked.. add event target/dataset.name to Previous Click
//cardtwo saves event target
    else if (previousClick === "" ) {
    previousClick = evt.target.dataset.name
        cardTwo = this;
// if previousClick == justClicked winner.. and render bb
         if (previousClick === justClicked){
            console.log("You have a match! .. you go girl")
         }
// if they don't match remove the flipped class.. and render bb
         else {
             console.log("Not a Weiner")
             cardOne.classList.remove('flipped')
             timeout()
             cardTwo.classList.remove('flipped')
             timeout()
         }        
        }
        previousClick = ""
        justClicked = ""
        cardOne = ""
        cardTwo = ""
    if (justClicked != "" && previousClick != "") {
        console.log(previousClick, justClicked)
    }
}


//turn the cards back over
//get rid of whatever is in the strings
function render(){

}

function timeout(){
    setTimeout(3000)
}
// 
   



// function initialize(){
//     let cardInPlay=[]
//     for(let i = 0; i < cardArray.length; i++)
//     cardInPlay.push(cardArray[i])
//     cardInPlay.push(cardArray[i])
// }

// if (cardOneId !== cardTwoId){
//     card.removeEventListener
//     }
// else if(cardOneId === cardTwoId){
//     return 0
//     console.log(evt.target)


// function addone(){
//     let counter = document.querySelector('#output').innerHTML
//     counter++
//     document.querySelector('#output').innerHTML = counter
// }


